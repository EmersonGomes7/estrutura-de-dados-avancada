#include "lib.h"

int main() {
	menu();
}
